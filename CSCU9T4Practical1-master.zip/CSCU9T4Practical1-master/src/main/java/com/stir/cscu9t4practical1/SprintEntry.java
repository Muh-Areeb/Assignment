package com.stir.cscu9t4practical1;
class SprintEntry extends Entry {
    private int Rounds;
    private int recoveryTime;
    public SprintEntry (String n, int d, int m, int y, int h, int min, int s, float dist, int r, int rt){
         super(n,d,m,y,h,min,s,dist);
         r=Rounds;
         rt=recoveryTime;
    }
    public int getRepetitions () {
        return Rounds;
    }
    public int getRecovery() {
            return recoveryTime;
    }
    public String getEntry() {
        String result = getName() + "Sprinted" + getDistance() + "km in" + getHour() + "i" + getMin() + ":"
                + getSec() + "on" + getDay() + "/" + getMonth() + "/" + getYear() + "at"+ getRepetitions()+"\n" + getRecovery() +"\n";
        return result;}
    }

